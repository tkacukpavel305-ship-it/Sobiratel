package com.example.sobiratel

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Account(
    val name: String,
    val crystals: Int = 0,
    val collected: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SoBiratelApp() }
    }

    private fun openUnlucid() {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://unlucid.info/")))
    }

    @Composable
    fun SoBiratelApp() {
        var accounts by remember {
            mutableStateOf((1..10).map { Account("Аккаунт $it") })
        }

        MaterialTheme {
            Scaffold(
                topBar = {
                    TopAppBar(title = { Text("Собиратель") })
                }
            ) { padding ->
                LazyColumn(
                    modifier = Modifier.padding(padding).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text(
                            "Помощник для ручного получения ежедневных наград",
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = { openUnlucid() },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Открыть Unlucid") }
                    }

                    items(accounts.indices.toList()) { index ->
                        val account = accounts[index]
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text(account.name, style = MaterialTheme.typography.titleMedium)
                                Text("Баланс: ${account.crystals} кристаллов")
                                Text(
                                    if (account.collected) "Статус: собрано сегодня"
                                    else "Статус: не собрано"
                                )
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { openUnlucid() }) {
                                        Text("Открыть")
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            accounts = accounts.toMutableList().also {
                                                it[index] = account.copy(collected = !account.collected)
                                            }
                                        }
                                    ) {
                                        Text(if (account.collected) "Отменить" else "Собрано")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
